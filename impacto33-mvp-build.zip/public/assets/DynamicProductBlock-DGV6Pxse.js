import{j as e,i as y}from"./index-Bd_0ugf_.js";import{g as l,u as g}from"./apollo-vendor-BacbZ8yz.js";import{r as N,L as f}from"./react-vendor-DeVBx3ip.js";import{B as h}from"./button-BfTTocta.js";import{S as m}from"./skeleton-CeZTxeV6.js";import{m as k,L as B}from"./ui-vendor-CKTUTQ3F.js";l`
  query GetProductCategories {
    productCategories(first: 100) {
      nodes {
        id
        name
        slug
        count
        parentId
        children {
          nodes {
            id
            name
            slug
            count
          }
        }
      }
    }
  }
`;const j=l`
  query GetProductsByCategory(
    $categorySlug: String!, 
    $first: Int!, 
    $after: String,
    $minPrice: Float,
    $maxPrice: Float
  ) {
    products(
      where: { 
        category: $categorySlug,
        minPrice: $minPrice,
        maxPrice: $maxPrice
      }, 
      first: $first, 
      after: $after
    ) {
      pageInfo {
        hasNextPage
        endCursor
      }
      nodes {
        id
        name
        slug
        ... on SimpleProduct {
          price
          regularPrice
          salePrice
        }
        ... on VariableProduct {
          price
          regularPrice
          salePrice
        }
        image {
          sourceUrl
          altText
        }
      }
    }
  }
`;l`
  query GetFeaturedProducts($first: Int!) {
    products(where: { featured: true }, first: $first) {
      nodes {
        id
        name
        slug
        image {
          sourceUrl
          altText
        }
        ... on SimpleProduct {
          price
        }
        ... on VariableProduct {
          price
        }
      }
    }
  }
`;function I({categorySlug:D,limit:a=12,columns:u=4,filters:d}){const{data:p,loading:n,error:P,fetchMore:x}=g(j,{variables:{categorySlug:D,first:a,after:null,minPrice:d?.minPrice,maxPrice:d?.maxPrice},notifyOnNetworkStatusChange:!0}),t=N.useRef(null),s=p?.products?.nodes||[],r=p?.products?.pageInfo||{hasNextPage:!1,endCursor:null},v=n&&s.length>0;return N.useEffect(()=>{const c=new IntersectionObserver(o=>{o[0].isIntersecting&&r.hasNextPage&&!n&&x({variables:{after:r.endCursor},updateQuery:(b,{fetchMoreResult:i})=>i?{products:{...i.products,nodes:[...b.products.nodes,...i.products.nodes]}}:b})},{threshold:.5});return t.current&&c.observe(t.current),()=>{t.current&&c.unobserve(t.current)}},[r.hasNextPage,r.endCursor,n,x]),n&&s.length===0?e.jsxDEV("div",{"data-loc":"client/src/components/DynamicProductBlock.tsx:90",className:`grid grid-cols-2 md:grid-cols-${u} gap-6`,children:Array.from({length:a}).map((c,o)=>e.jsxDEV("div",{"data-loc":"client/src/components/DynamicProductBlock.tsx:92",className:"space-y-4",children:[e.jsxDEV(m,{"data-loc":"client/src/components/DynamicProductBlock.tsx:93",className:"h-64 w-full rounded-sm"},void 0,!1,{fileName:"/home/ubuntu/impacto33-mvp/client/src/components/DynamicProductBlock.tsx",lineNumber:93,columnNumber:13},this),e.jsxDEV(m,{"data-loc":"client/src/components/DynamicProductBlock.tsx:94",className:"h-4 w-3/4"},void 0,!1,{fileName:"/home/ubuntu/impacto33-mvp/client/src/components/DynamicProductBlock.tsx",lineNumber:94,columnNumber:13},this),e.jsxDEV(m,{"data-loc":"client/src/components/DynamicProductBlock.tsx:95",className:"h-4 w-1/2"},void 0,!1,{fileName:"/home/ubuntu/impacto33-mvp/client/src/components/DynamicProductBlock.tsx",lineNumber:95,columnNumber:13},this)]},o,!0,{fileName:"/home/ubuntu/impacto33-mvp/client/src/components/DynamicProductBlock.tsx",lineNumber:92,columnNumber:11},this))},void 0,!1,{fileName:"/home/ubuntu/impacto33-mvp/client/src/components/DynamicProductBlock.tsx",lineNumber:90,columnNumber:7},this):P?e.jsxDEV("div",{"data-loc":"client/src/components/DynamicProductBlock.tsx:104",className:"bg-red-50 border border-red-100 text-red-800 p-8 rounded-sm text-center",children:[e.jsxDEV(k,{"data-loc":"client/src/components/DynamicProductBlock.tsx:105",className:"mx-auto mb-2 h-8 w-8 text-red-500"},void 0,!1,{fileName:"/home/ubuntu/impacto33-mvp/client/src/components/DynamicProductBlock.tsx",lineNumber:105,columnNumber:9},this),e.jsxDEV("p",{"data-loc":"client/src/components/DynamicProductBlock.tsx:106",className:"font-medium",children:"Error cargando productos"},void 0,!1,{fileName:"/home/ubuntu/impacto33-mvp/client/src/components/DynamicProductBlock.tsx",lineNumber:106,columnNumber:9},this),e.jsxDEV("p",{"data-loc":"client/src/components/DynamicProductBlock.tsx:107",className:"text-sm opacity-80 mt-1",children:"Por favor, intenta recargar la página."},void 0,!1,{fileName:"/home/ubuntu/impacto33-mvp/client/src/components/DynamicProductBlock.tsx",lineNumber:107,columnNumber:9},this)]},void 0,!0,{fileName:"/home/ubuntu/impacto33-mvp/client/src/components/DynamicProductBlock.tsx",lineNumber:104,columnNumber:7},this):s.length===0?e.jsxDEV("div",{"data-loc":"client/src/components/DynamicProductBlock.tsx:114",className:"bg-slate-50 border border-slate-100 text-slate-600 p-12 rounded-sm text-center",children:[e.jsxDEV("p",{"data-loc":"client/src/components/DynamicProductBlock.tsx:115",className:"font-medium",children:"No se encontraron productos en esta categoría."},void 0,!1,{fileName:"/home/ubuntu/impacto33-mvp/client/src/components/DynamicProductBlock.tsx",lineNumber:115,columnNumber:9},this),e.jsxDEV(f,{"data-loc":"client/src/components/DynamicProductBlock.tsx:116",href:"/contacto",children:e.jsxDEV(h,{"data-loc":"client/src/components/DynamicProductBlock.tsx:117",variant:"link",className:"mt-2 text-blue-700",children:"Contáctanos para consultar disponibilidad"},void 0,!1,{fileName:"/home/ubuntu/impacto33-mvp/client/src/components/DynamicProductBlock.tsx",lineNumber:117,columnNumber:11},this)},void 0,!1,{fileName:"/home/ubuntu/impacto33-mvp/client/src/components/DynamicProductBlock.tsx",lineNumber:116,columnNumber:9},this)]},void 0,!0,{fileName:"/home/ubuntu/impacto33-mvp/client/src/components/DynamicProductBlock.tsx",lineNumber:114,columnNumber:7},this):e.jsxDEV("div",{"data-loc":"client/src/components/DynamicProductBlock.tsx:124",className:"space-y-8",children:[e.jsxDEV("div",{"data-loc":"client/src/components/DynamicProductBlock.tsx:125",className:`grid grid-cols-2 md:grid-cols-3 lg:grid-cols-${u} gap-6`,children:s.map(c=>{const o=c.salePrice||c.price||c.regularPrice;return e.jsxDEV(f,{"data-loc":"client/src/components/DynamicProductBlock.tsx:130",href:`/producto/${c.slug}`,children:e.jsxDEV("div",{"data-loc":"client/src/components/DynamicProductBlock.tsx:131",className:"group cursor-pointer border border-transparent hover:border-slate-200 hover:shadow-lg transition-all duration-200 p-4 rounded-sm bg-white h-full flex flex-col",children:[e.jsxDEV("div",{"data-loc":"client/src/components/DynamicProductBlock.tsx:132",className:"relative aspect-square overflow-hidden mb-4 bg-slate-50 rounded-sm",children:c.image?.sourceUrl?e.jsxDEV("img",{"data-loc":"client/src/components/DynamicProductBlock.tsx:134",src:c.image.sourceUrl,alt:c.image.altText||c.name,className:"object-cover w-full h-full group-hover:scale-105 transition-transform duration-300",loading:"lazy"},void 0,!1,{fileName:"/home/ubuntu/impacto33-mvp/client/src/components/DynamicProductBlock.tsx",lineNumber:134,columnNumber:21},this):e.jsxDEV("div",{"data-loc":"client/src/components/DynamicProductBlock.tsx:141",className:"w-full h-full flex items-center justify-center text-slate-300 bg-slate-100",children:e.jsxDEV("span",{"data-loc":"client/src/components/DynamicProductBlock.tsx:142",className:"text-xs uppercase font-bold",children:"Sin imagen"},void 0,!1,{fileName:"/home/ubuntu/impacto33-mvp/client/src/components/DynamicProductBlock.tsx",lineNumber:142,columnNumber:23},this)},void 0,!1,{fileName:"/home/ubuntu/impacto33-mvp/client/src/components/DynamicProductBlock.tsx",lineNumber:141,columnNumber:21},this)},void 0,!1,{fileName:"/home/ubuntu/impacto33-mvp/client/src/components/DynamicProductBlock.tsx",lineNumber:132,columnNumber:17},this),e.jsxDEV("div",{"data-loc":"client/src/components/DynamicProductBlock.tsx:147",className:"flex-grow flex flex-col",children:[e.jsxDEV("h3",{"data-loc":"client/src/components/DynamicProductBlock.tsx:148",className:"font-bold text-slate-900 text-sm mb-1 line-clamp-2 group-hover:text-blue-700 transition-colors",children:c.name},void 0,!1,{fileName:"/home/ubuntu/impacto33-mvp/client/src/components/DynamicProductBlock.tsx",lineNumber:148,columnNumber:19},this),e.jsxDEV("div",{"data-loc":"client/src/components/DynamicProductBlock.tsx:152",className:"mt-auto pt-3 flex items-center justify-between",children:e.jsxDEV("div",{"data-loc":"client/src/components/DynamicProductBlock.tsx:153",className:"text-xs text-slate-500",children:["Desde ",e.jsxDEV("span",{"data-loc":"client/src/components/DynamicProductBlock.tsx:154",className:"text-slate-900 font-bold text-base",children:y(o)},void 0,!1,{fileName:"/home/ubuntu/impacto33-mvp/client/src/components/DynamicProductBlock.tsx",lineNumber:154,columnNumber:29},this)]},void 0,!0,{fileName:"/home/ubuntu/impacto33-mvp/client/src/components/DynamicProductBlock.tsx",lineNumber:153,columnNumber:21},this)},void 0,!1,{fileName:"/home/ubuntu/impacto33-mvp/client/src/components/DynamicProductBlock.tsx",lineNumber:152,columnNumber:19},this),e.jsxDEV(h,{"data-loc":"client/src/components/DynamicProductBlock.tsx:158",variant:"outline",size:"sm",className:"w-full mt-3 border-slate-200 text-slate-700 hover:bg-blue-700 hover:text-white hover:border-blue-700 transition-colors text-xs uppercase font-bold tracking-wide",children:"Ver Producto"},void 0,!1,{fileName:"/home/ubuntu/impacto33-mvp/client/src/components/DynamicProductBlock.tsx",lineNumber:158,columnNumber:19},this)]},void 0,!0,{fileName:"/home/ubuntu/impacto33-mvp/client/src/components/DynamicProductBlock.tsx",lineNumber:147,columnNumber:17},this)]},void 0,!0,{fileName:"/home/ubuntu/impacto33-mvp/client/src/components/DynamicProductBlock.tsx",lineNumber:131,columnNumber:15},this)},c.id,!1,{fileName:"/home/ubuntu/impacto33-mvp/client/src/components/DynamicProductBlock.tsx",lineNumber:130,columnNumber:13},this)})},void 0,!1,{fileName:"/home/ubuntu/impacto33-mvp/client/src/components/DynamicProductBlock.tsx",lineNumber:125,columnNumber:7},this),e.jsxDEV("div",{"data-loc":"client/src/components/DynamicProductBlock.tsx:173",ref:t,className:"h-10 flex items-center justify-center w-full",children:v&&e.jsxDEV("div",{"data-loc":"client/src/components/DynamicProductBlock.tsx:175",className:"flex items-center gap-2 text-slate-500",children:[e.jsxDEV(B,{"data-loc":"client/src/components/DynamicProductBlock.tsx:176",className:"h-5 w-5 animate-spin"},void 0,!1,{fileName:"/home/ubuntu/impacto33-mvp/client/src/components/DynamicProductBlock.tsx",lineNumber:176,columnNumber:13},this),e.jsxDEV("span",{"data-loc":"client/src/components/DynamicProductBlock.tsx:177",className:"text-sm font-medium",children:"Cargando más productos..."},void 0,!1,{fileName:"/home/ubuntu/impacto33-mvp/client/src/components/DynamicProductBlock.tsx",lineNumber:177,columnNumber:13},this)]},void 0,!0,{fileName:"/home/ubuntu/impacto33-mvp/client/src/components/DynamicProductBlock.tsx",lineNumber:175,columnNumber:11},this)},void 0,!1,{fileName:"/home/ubuntu/impacto33-mvp/client/src/components/DynamicProductBlock.tsx",lineNumber:173,columnNumber:7},this)]},void 0,!0,{fileName:"/home/ubuntu/impacto33-mvp/client/src/components/DynamicProductBlock.tsx",lineNumber:124,columnNumber:5},this)}export{I as D};
